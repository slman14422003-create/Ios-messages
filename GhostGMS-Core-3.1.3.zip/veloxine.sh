#!/system/bin/sh
##########################################################################################
# GhostGMS Service Script
# Authors: Kaushik, MiguVT
# Version: 3.0
##########################################################################################

# Check for command line arguments
COMMAND=${1:-"status"}

# Derive MODDIR from script location (matches service.sh behavior)
# Avoids hardcoding path which breaks when module id case differs
MODDIR="${0%/*}"

# Persistent fallback directory (same as service.sh and customize.sh)
PERSISTENT_CONFIG="/data/local/tmp/ghostgms_config"

# Set up logging
LOGDIR="$MODDIR/logs"
mkdir -p "$LOGDIR" 2>/dev/null
# If module logs dir isn't writable, fall back to persistent location
if [ ! -d "$LOGDIR" ] || [ ! -w "$LOGDIR" ]; then
  LOGDIR="$PERSISTENT_CONFIG/logs"
  mkdir -p "$LOGDIR" 2>/dev/null
fi
LOGFILE="$LOGDIR/ghostgms_service.log"
exec >> $LOGFILE 2>&1

# Define packages
GMS_PACKAGE="com.google.android.gms"
GSF_PACKAGE="com.google.android.gsf"

# Log start time with command
echo "[$(date '+%Y-%m-%d %H:%M:%S')] GhostGMS Service started with command: $COMMAND"
echo "[INFO] MODDIR=$MODDIR"

# Load user preferences with fallback to persistent location
if [ -f "$MODDIR/config/user_prefs" ]; then
  . "$MODDIR/config/user_prefs"
  echo "[INFO] User preferences loaded from module directory"
elif [ -f "$PERSISTENT_CONFIG/user_prefs" ]; then
  echo "[INFO] User preferences found in persistent fallback, copying to module directory"
  mkdir -p "$MODDIR/config" 2>/dev/null
  cp "$PERSISTENT_CONFIG/user_prefs" "$MODDIR/config/user_prefs" 2>/dev/null
  chmod 644 "$MODDIR/config/user_prefs" 2>/dev/null
  . "$PERSISTENT_CONFIG/user_prefs"
else
  echo "[WARNING] User preferences not found, creating safe defaults"
  mkdir -p "$MODDIR/config" 2>/dev/null
  {
    echo "ENABLE_GHOSTED=1"
    echo "ENABLE_LOG_DISABLE=1"
    echo "ENABLE_SYS_PROPS=1"
    echo "ENABLE_BLUR_DISABLE=0"
    echo "ENABLE_SERVICES_DISABLE=1"
    echo "ENABLE_RECEIVER_DISABLE=0"
    echo "ENABLE_PROVIDER_DISABLE=0"
    echo "ENABLE_ACTIVITY_DISABLE=0"
  } > "$MODDIR/config/user_prefs" 2>/dev/null
  chmod 644 "$MODDIR/config/user_prefs" 2>/dev/null
  # Also save to persistent fallback
  mkdir -p "$PERSISTENT_CONFIG" 2>/dev/null
  cp "$MODDIR/config/user_prefs" "$PERSISTENT_CONFIG/user_prefs" 2>/dev/null
  chmod 644 "$PERSISTENT_CONFIG/user_prefs" 2>/dev/null
  # Load the defaults
  if [ -f "$MODDIR/config/user_prefs" ]; then
    . "$MODDIR/config/user_prefs"
  elif [ -f "$PERSISTENT_CONFIG/user_prefs" ]; then
    . "$PERSISTENT_CONFIG/user_prefs"
  else
    # Inline defaults as last resort
    ENABLE_GHOSTED=1; ENABLE_LOG_DISABLE=1; ENABLE_SYS_PROPS=1
    ENABLE_BLUR_DISABLE=0; ENABLE_SERVICES_DISABLE=1
    ENABLE_RECEIVER_DISABLE=0; ENABLE_PROVIDER_DISABLE=0; ENABLE_ACTIVITY_DISABLE=0
    echo "[WARNING] Could not write config files, using inline defaults"
  fi
fi

# Load GMS categories preferences with fallback
echo "[INFO] Loading GMS categories preferences"
if [ -f "$MODDIR/config/gms_categories" ]; then
  . "$MODDIR/config/gms_categories"
  echo "[INFO] GMS categories loaded from module directory"
elif [ -f "$PERSISTENT_CONFIG/gms_categories" ]; then
  echo "[INFO] GMS categories found in persistent fallback, copying to module directory"
  mkdir -p "$MODDIR/config" 2>/dev/null
  cp "$PERSISTENT_CONFIG/gms_categories" "$MODDIR/config/gms_categories" 2>/dev/null
  chmod 644 "$MODDIR/config/gms_categories" 2>/dev/null
  . "$PERSISTENT_CONFIG/gms_categories"
else
  echo "[WARNING] GMS categories file not found, using defaults"
  # Default values for GMS service categories
  DISABLE_ADS=1
  DISABLE_TRACKING=1
  DISABLE_ANALYTICS=1
  DISABLE_REPORTING=1
  DISABLE_BACKGROUND=1
  DISABLE_UPDATE=1
  DISABLE_LOCATION=0
  DISABLE_GEOFENCE=0
  DISABLE_NEARBY=0
  DISABLE_CAST=0
  DISABLE_DISCOVERY=0
  DISABLE_SYNC=0
  DISABLE_CLOUD=0
  DISABLE_AUTH=0
  DISABLE_WALLET=0
  DISABLE_PAYMENT=0
  DISABLE_WEAR=0
  DISABLE_FITNESS=0
fi

# Function to show notification
show_notification() {
  local TITLE="GhostGMS"
  local MESSAGE="$1"
  local PRIORITY=$2
  
  # Try PowerSaver app first
  am start -a android.intent.action.MAIN -e powersaver "$MESSAGE" -n powersaver.pro/.MainActivity >/dev/null 2>&1
  
  # Fallback to basic notification if PowerSaver isn't available
  if [ $? -ne 0 ]; then
    am startservice -a android.intent.action.RUN \
      -e short "$TITLE" -e long "$MESSAGE" -e priority "$PRIORITY" \
      -n com.android.shell/.BugreportWarningService >/dev/null 2>&1
  fi
}

# Function to process service based on category
toggle_gms_service() {
  local FULL_SERVICE_NAME=$1
  local CATEGORY=$2
  local ACTION=$3
  local SHOULD_DISABLE=0
  
  # Skip if category is not set or service is not properly formatted
  if [ -z "$CATEGORY" ] || [ "$CATEGORY" = "null" ]; then
    echo "[INFO] Skipping service $FULL_SERVICE_NAME (no category)"
    return
  fi

  # Extract service name without package if it has package name
  local SERVICE_NAME
  case "$FULL_SERVICE_NAME" in
    */*)
      SERVICE_NAME=$(echo "$FULL_SERVICE_NAME" | cut -d'/' -f2)
      ;;
    *)
      SERVICE_NAME=$FULL_SERVICE_NAME
      FULL_SERVICE_NAME="${GMS_PACKAGE}/${SERVICE_NAME}"
      ;;
  esac
  
  # If action is "enable", we enable all services
  if [ "$ACTION" = "enable" ]; then
    echo "[INFO] Enabling service $FULL_SERVICE_NAME"
    pm enable $FULL_SERVICE_NAME >/dev/null 2>&1
    return
  fi
  
  # For disable action, determine if we should disable based on category
  case $CATEGORY in
    "ads")
      SHOULD_DISABLE=$DISABLE_ADS
      ;;
    "tracking")
      SHOULD_DISABLE=$DISABLE_TRACKING
      ;;
    "analytics")
      SHOULD_DISABLE=$DISABLE_ANALYTICS
      ;;
    "reporting")
      SHOULD_DISABLE=$DISABLE_REPORTING
      ;;
    "background")
      SHOULD_DISABLE=$DISABLE_BACKGROUND
      ;;
    "update")
      SHOULD_DISABLE=$DISABLE_UPDATE
      ;;
    "location")
      SHOULD_DISABLE=$DISABLE_LOCATION
      ;;
    "geofence")
      SHOULD_DISABLE=$DISABLE_GEOFENCE
      ;;
    "nearby")
      SHOULD_DISABLE=$DISABLE_NEARBY
      ;;
    "cast")
      SHOULD_DISABLE=$DISABLE_CAST
      ;;
    "discovery")
      SHOULD_DISABLE=$DISABLE_DISCOVERY
      ;;
    "sync")
      SHOULD_DISABLE=$DISABLE_SYNC
      ;;
    "cloud")
      SHOULD_DISABLE=$DISABLE_CLOUD
      ;;
    "auth")
      SHOULD_DISABLE=$DISABLE_AUTH
      ;;
    "wallet")
      SHOULD_DISABLE=$DISABLE_WALLET
      ;;
    "payment")
      SHOULD_DISABLE=$DISABLE_PAYMENT
      ;;
    "wear")
      SHOULD_DISABLE=$DISABLE_WEAR
      ;;
    "fitness")
      SHOULD_DISABLE=$DISABLE_FITNESS
      ;;
    "core"|"essential")
      # Never disable core/essential services
      SHOULD_DISABLE=0
      ;;
    *)
      echo "[WARNING] Unknown category: $CATEGORY for service $FULL_SERVICE_NAME"
      return
      ;;
  esac
  
  # Disable service based on category preferences
  if [ "$SHOULD_DISABLE" = "1" ]; then
    echo "[INFO] Disabling service $FULL_SERVICE_NAME (category: $CATEGORY)"
    if pm disable $FULL_SERVICE_NAME >/dev/null 2>&1; then
      :  # Success
    else
      echo "[WARNING] Failed to disable service $FULL_SERVICE_NAME (may already be disabled or system lock)"
    fi
  else
    echo "[INFO] Keeping service $FULL_SERVICE_NAME (category: $CATEGORY)"
    if pm enable $FULL_SERVICE_NAME >/dev/null 2>&1; then
      :  # Success
    else
      echo "[WARNING] Failed to enable service $FULL_SERVICE_NAME (may already be enabled or system lock)"
    fi
  fi
  
  # Small delay to prevent overwhelming the system with rapid pm commands
  sleep 0.05
}

# Process services from gmslist.txt
process_services() {
  local ACTION=$1
  echo "[INFO] Processing GMS services with action: $ACTION"
  
  if [ ! -f "$MODDIR/gmslist.txt" ]; then
    echo "[ERROR] gmslist.txt not found. Cannot proceed with service toggling."
    return 1
  fi
  
  # Count total services for progress tracking
  local TOTAL_SERVICES=$(grep -v "^#" "$MODDIR/gmslist.txt" | grep -v "^$" | wc -l)
  local COUNTER=0
  
  while IFS="|" read -r SERVICE CATEGORY || [ -n "$SERVICE" ]; do
    # Skip comments and empty lines
    case "$SERVICE" in
      \#*|"") continue ;;
    esac
    
    # Process service
    toggle_gms_service "$SERVICE" "$CATEGORY" "$ACTION"
    
    # Update counter for progress
    COUNTER=$((COUNTER+1))
    
    # Show progress notification every 20 services
    if [ $((COUNTER % 20)) -eq 0 ]; then
      show_notification "Processing $COUNTER/$TOTAL_SERVICES services..." "low"
    fi
    
    # Add a small delay to prevent overwhelming the system
    sleep 0.01
  done < "$MODDIR/gmslist.txt"
  
  echo "[INFO] Processed $COUNTER/$TOTAL_SERVICES services"
  return 0
}

# Always re-enable core/essential services regardless of user preference.
# This ensures previously disabled core services (e.g. from a prior install)
# are restored even when ENABLE_SERVICES_DISABLE=0.
ensure_core_services() {
  echo "[INFO] Ensuring core/essential services are enabled"

  if [ ! -f "$MODDIR/gmslist.txt" ]; then
    echo "[WARNING] gmslist.txt not found, skipping core service check"
    return
  fi

  local FULL_SERVICE_NAME
  while IFS="|" read -r SERVICE CATEGORY || [ -n "$SERVICE" ]; do
    # Skip comments and empty lines
    case "$SERVICE" in
      \#*|"") continue ;;
    esac

    case "$CATEGORY" in
      "core"|"essential")
        # Build fully-qualified service name
        case "$SERVICE" in
          */*)
            FULL_SERVICE_NAME="$SERVICE"
            ;;
          *)
            FULL_SERVICE_NAME="${GMS_PACKAGE}/${SERVICE}"
            ;;
        esac
        echo "[INFO] Ensuring core service is enabled: $FULL_SERVICE_NAME"
        pm enable "$FULL_SERVICE_NAME" >/dev/null 2>&1
        ;;
    esac
  done < "$MODDIR/gmslist.txt"

  echo "[INFO] Core/essential service check complete"
}

# Wait for Settings database to be ready with timeout
wait_for_settings_ready() {
  local max_attempts=30
  local attempt=0
  
  echo "[INFO] Waiting for Settings database to be ready..."
  
  while [ $attempt -lt $max_attempts ]; do
    # Test if settings command works
    if settings get global sys_usb >/dev/null 2>&1; then
      echo "[INFO] Settings database ready after $((attempt + 1)) seconds"
      return 0
    fi
    
    attempt=$((attempt + 1))
    sleep 1
  done
  
  echo "[WARNING] Settings database not ready after $max_attempts seconds, proceeding anyway (may cause transaction errors)"
  return 1
}

# Safely put settings with retry logic
safe_settings_put() {
  local key=$1
  local value=$2
  local max_retries=3
  local retry=0
  
  while [ $retry -lt $max_retries ]; do
    if settings put global "$key" "$value" >/dev/null 2>&1; then
      return 0
    fi
    
    retry=$((retry + 1))
    if [ $retry -lt $max_retries ]; then
      echo "[WARNING] Failed to set $key, retrying in 2 seconds (attempt $retry/$max_retries)"
      sleep 2
    fi
  done
  
  echo "[ERROR] Failed to set $key after $max_retries attempts (may be read-only or system lock)"
  return 1
}

# Function to disable GMS logs
disable_gms_logs() {
  if [ "$ENABLE_LOG_DISABLE" = "1" ]; then
    echo "[INFO] Disabling GMS logging"
    
    # Wait for settings to be ready
    wait_for_settings_ready
    
    # Use safe_settings_put to handle errors and retries
    safe_settings_put "gmscorestat_enabled" "0"
    safe_settings_put "play_store_panel_logging_enabled" "0"
    safe_settings_put "clearcut_events" "0"
    safe_settings_put "clearcut_gcm" "0"
    safe_settings_put "phenotype__debug_bypass_phenotype" "1"
    safe_settings_put "phenotype_boot_count" "99"
    safe_settings_put "phenotype_flags" "disable_log_upload=1,disable_log_for_missing_debug_id=1"
    
    # Disable analytics and error reporting
    safe_settings_put "ga_collection_enabled" "0"
    safe_settings_put "clearcut_enabled" "0"
    safe_settings_put "analytics_enabled" "0"
    safe_settings_put "uploading_enabled" "0"
    safe_settings_put "bug_report_in_power_menu" "0"
    
    # Disable usage stats
    safe_settings_put "usage_stats_enabled" "0"
    safe_settings_put "usagestats_collection_enabled" "0"
    
    echo "[INFO] GMS logging disable operations completed"
  else
    echo "[INFO] GMS logging not disabled (user preference)"
  fi
}

# Main functionality based on command
case "$COMMAND" in
  "disable"|"off")
    echo "[INFO] Disabling GMS services..."
    # Apply service disabling
    if [ "$ENABLE_SERVICES_DISABLE" = "1" ] && [ -f "$MODDIR/gmslist.txt" ]; then
      process_services "disable"
    else
      echo "[INFO] Service disabling not enabled by user preference"
    fi
    
    # Apply log disabling
    disable_gms_logs
    
    # Show completion notification
    show_notification "GMS services have been DISABLED" "normal"
    ;;
    
  "enable"|"on")
    echo "[INFO] Enabling GMS services..."
    # Enable all GMS services
    if [ -f "$MODDIR/gmslist.txt" ]; then
      process_services "enable"
    else
      echo "[ERROR] gmslist.txt not found. Cannot proceed with service enabling."
    fi
    
    # Show completion notification
    show_notification "GMS services have been ENABLED" "normal"
    ;;
    
  "boot")
    echo "[INFO] Processing boot-time GMS configuration..."
    
    # Additional safety delay to ensure system is fully stable
    sleep 10
    
    # Always re-enable core/essential services (e.g. location, chimera infrastructure)
    # even when service disabling is turned off, to recover from a previous install
    # that may have disabled them.
    ensure_core_services
    
    # Apply service disabling on boot
    if [ "$ENABLE_SERVICES_DISABLE" = "1" ] && [ -f "$MODDIR/gmslist.txt" ]; then
      process_services "disable"
    else
      echo "[INFO] Service disabling not enabled by user preference"
    fi
    
    # Apply log disabling
    disable_gms_logs
    ;;
    
  "status")
    echo "[INFO] Checking GMS services status"
    show_notification "GhostGMS is active" "low"
    ;;
    
  *)
    echo "[INFO] Unknown command: $COMMAND"
    echo "[INFO] Valid commands: enable, disable, boot, status"
    ;;
esac

# Log completion
echo "[$(date '+%Y-%m-%d %H:%M:%S')] GhostGMS Service completed successfully"
exit 0 