# Changelog

## v3.1.3 (Latest)

### 🔧 Critical Fix

#### ✅ Fix Quick Share crashing and Bluetooth breakage (Issue: Quick Share closes immediately)
- **Root Cause:** Core GMS Chimera IPC broker services (`PersistentBoundBrokerService`, `GmsApiService`, `GmsIntentOperationService`) were incorrectly categorised as `background` in `gmslist.txt`. Since `DISABLE_BACKGROUND=1` is the default, these services were disabled on every boot.
- **Impact:** These services are the IPC backbone for **all** GMS API calls. Disabling them causes Quick Share to crash on launch and breaks any GMS feature that relies on Bluetooth or Nearby Connections (Fast Pair, Nearby Share, etc.).
- **Fixed:** Changed category of `PersistentBoundBrokerService`, `GmsApiService`, and `GmsIntentOperationService` from `background` to `core` so they are never disabled.
- **Also Fixed:** Four `_AuthAccountIsolated` Chimera variants were listed twice — once correctly under `auth` (kept enabled) and again under `background` (disabled). The duplicate `background` entry was winning last, causing them to be disabled even though `DISABLE_AUTH=0`. Changed their category to `core` to prevent the conflict.
- **Also Fixed:** `GmsCoreStatsService` was duplicated between the `background` and `analytics` sections; removed the `background` entry to keep only the `analytics` one.

---

## v3.1.2 - 11 March 2026

### 🔧 Critical Fix

#### ✅ Fix veloxine.sh hardcoded MODDIR path (Issue: files disappear after boot)
- **Fixed:** `veloxine.sh` hardcoded `MODDIR="/data/adb/modules/GhostGMS"` (mixed case) but `module.prop` defines `id=ghostgms` (lowercase). Android filesystems are case-sensitive, so the script could never find config files or gmslist.txt at the wrong-cased path
- **Fixed:** Replaced hardcoded path with `MODDIR="${0%/*}"` (derived from script location), matching how `service.sh` already works
- **Fixed:** Added persistent config fallback to `veloxine.sh` (checks `/data/local/tmp/ghostgms_config/`) — previously only `service.sh` had this fallback
- **Fixed:** `veloxine.sh` no longer fatally exits (`exit 1`) when config is missing — instead creates safe defaults and continues, matching `service.sh` behavior
- **Fixed:** Log directory creation now falls back to persistent location if module directory isn't writable
- **Impact:** Resolves the "User preferences file not found" error that caused the optimization service to silently die after boot
- **Symptom:** Module files appeared to vanish from `/debug_ramdisk/.magisk/modules/GhostGMS/` — users were actually seeing an orphan directory created by the wrong-cased path

---

## v3.1.1
- **Fixed:** Fix config persistence on APatch/KernelSU Next

## v3.1 

### 🔧 Critical Fixes

#### ✅ Comprehensive Uninstall Script
- **Fixed:** Uninstall script now properly reverses **ALL** changes made by the module  
- **System Settings:** Correctly restores analytics, logging, bug reporting, and usage stats  
- **Runtime Properties:** Properly removes all resetprop changes (tombstone, LMK, Dalvik, blur settings)  
- **GMS Services:** Re-enables all disabled services including location, auth, backup, and crash reporting  
- **Logging:** Added uninstall logging to `/data/local/tmp/ghostgms_uninstall.log` for debugging  
- **Impact:** Module now provides complete reversibility - uninstalling returns device to exact pre-installation state  
- **Previous Behavior:** Only re-enabled services but left settings/properties modified

#### ✅ KernelSU Next / APatch Compatibility (Issue #8)
- **Fixed:** Module now works properly with KernelSU Next and APatch root managers  
- **Core Module:** Added proper permissions (`chmod 755`/`644`) for config files  
- **Core Module:** Added validation and warning if config creation fails during installation  
- **Core Module:** Auto-creates config files with safe defaults if missing on boot  
- **Legacy Module:** FIXED critical bug - config files were never created during installation!  
- **Legacy Module:** Now creates `user_prefs` and `gms_categories` with default values  
- **Fallback Logic:** Both versions now auto-generate config files on boot if missing  
- **Error Logging:** Detailed logging to `boot_error.log` for troubleshooting  
- **Impact:** No more "User preferences not found" error on first boot  
- **Tested On:** Magisk, KernelSU, KernelSU Next v1.0.7+, APatch

### ✨ New Features

#### 🎨 Interactive Blur Disable Option
- **Added:** Volume button prompt during installation to optionally disable UI blur effects  
- **Default:** Blur stays enabled (safe for most ROMs)  
- **User Choice:** Users can now choose whether to disable blur based on their ROM  
- **Compatibility Fix:** Prevents transparent popups and unreadable notifications on OxygenOS/AOSP ROMs  
- **Configuration:** Preference saved and applied conditionally on boot  
- **Impact:** Better ROM compatibility without forcing blur changes on all users

### 🔄 Updates

- **Repository:** Updated GitHub username from `veloxineology` to `kaushikieeee`  
- **Links:** Updated all repository URLs, documentation, and workflow files  
- **Both Versions:** Core (3.1) and Legacy (1.3.1) both updated with all fixes  
- **Compatibility:** Confirmed working on Android 8-15, Magisk 20+, KernelSU, KernelSU Next, APatch

### 📝 Summary

This release focuses on **stability and compatibility** across all root managers. Major issues with KernelSU Next/APatch are now resolved, and the module provides full reversibility on uninstall. The interactive blur option improves ROM compatibility without breaking existing functionality.

**Upgrade Recommended:** If you're on v3.0 or earlier, especially with KernelSU Next/APatch, update to v3.1 immediately.

---

## v3.0
- **Reached Saturation Point:** GhostGMS is now fully optimized; adding more tweaks risks breaking Android or critical Google functionality.  
- **Dual Module Release:**  
  - **3.0 Core:** Safe optimizations with no kernel modifications; focuses on maximum battery, privacy, and performance while maintaining full stability.  
  - **2.0 Legacy:** Includes previous kernel tweaks and deeper system-level optimizations; may offer extra performance gains but could affect stability on some devices.  
- **Compatibility Updates:** Confirmed support for Android 10–14, with limited testing for Android 8–9.  
- **Final Major Feature Release:** Future updates will focus on bug fixes and minor refinements only.  

---

## v2.1
- Major update focused on compatibility, maintainability, and enhanced user experience.  
- **KernelSU Support:** Full compatibility with KernelSU alongside Magisk.  
- **Native Key Input Handling:** Legacy keycheck replaced with architecture-agnostic, reliable volume key detection using getevent.  
- **Redesigned Interactive Installer:** Sleek new wizard with clear section headers, emojis, timeout defaults, and a final confirmation screen.  
- **Cleaner Configuration & Storage:** User preferences and service categories saved in a structured, persistent format.  
- **Code Overhaul & UX Improvements:** Modular structure, clear defaults, smarter error handling, and polished user prompts throughout.  
- **Defaults Adjusted for Stability:** Only privacy-invading services (Ads, Tracking, Analytics, etc.) are disabled by default—everything else is opt-in to reduce breakage.  
- Huge thanks to @MiguVT for helping fix the input issue via pull request!  
- If you faced the volume key issue earlier, this release should fix it.  
- Join the support group: t.me/veloxineologysupport  

---

## v2.0
- Added advanced GMS service categorization system with granular control  
- Improved volume key detection for more reliable installation choices  
- Enhanced system property optimizations with focus on Android 14 compatibility  
- Removed action button functionality for simpler and more stable operation  
- Consolidated service management into improved veloxine.sh script  
- Improved notification system with PowerSaver app support and fallback method  
- Fixed compatibility issues with newer devices  
- Added extensive logging options for troubleshooting  

---

## v1.3
- Added system.prop optimizations for performance and battery  
- Implemented customizable installation options  
- Added action button toggle for GMS services  
- Improved cache cleanup routines  
- Enhanced kernel-level optimizations  
- Added support for both Magisk and KernelSU  
- Implemented automatic update checking  

---

## v1.2
- Added more GMS services to disable list  
- Improved logging system  
- Fixed compatibility with Android 13+  
- Added thermal optimization  

---

## v1.1
- Initial public release  
- Basic GMS service disabling  
- Simple action button implementation
